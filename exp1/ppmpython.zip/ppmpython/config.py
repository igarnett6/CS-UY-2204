#config values.

#random number range, default range is from 0 ~ 9
RANDOM_RANGE = [0, 9]
#2|10|16 (binary, deciminal or hexadecimal)
NUMBER_SYSTEM = 16
#True|False
SHOW_CODE_DIGIT = True
#players' name. 
PLAYER_NAME = ['Player 1', 'Player 2']
#['machine'|'human', 'machine'|'human']
PLAYER_TYPE = ['Human', 'Human']
